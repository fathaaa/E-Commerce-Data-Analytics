# Install Streamlit

```bash
pip install streamlit
```

## Run Dashboard on Local

```bash
streamlit run streamlit.py
```
